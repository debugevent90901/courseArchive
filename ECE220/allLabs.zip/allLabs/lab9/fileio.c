#include <stdlib.h>
#include <stdio.h>

#define NofS 3

#define EQUAL 0
#define NOTEQUAL 1

struct studentStruct
{
    char name[100];
    int ID;
    char grade;
};
typedef struct studentStruct Student;

/* these functions are provided, do not modify them */
void enterRecords(Student s[], int n);
void writeRecordsToFile(Student s[], int n, char *fname);

/* these functions need to be implemented */
void readRecordsFromFile(Student s[], int n, char *fname);
int compareRecords(Student s1[], Student s2[], int n);


int main()
{
    Student S1[NofS];
    Student S2[NofS];

    enterRecords(S1, NofS);
    writeRecordsToFile(S1, NofS, "ece220.dat");

    readRecordsFromFile(S2, NofS, "ece220.dat");

    if (compareRecords(S1, S2, NofS) == EQUAL)
        printf("Records are identical\n");
    else    
        printf("Records are different\n");

    return 0;
}

/* enterRecords - read students' information from keyboard input and store them to structures
 *
 * INPUTS: s[] - the array of the structures of student
 *         n - number of the students
 * OUTPUTS: output the name, ID and grade of students into the structures
 *
 * RETURN VALUE: none
 */
void enterRecords(Student s[], int n)
{
    int i;
    char temp[8];
    for (i = 0; i < n; i++)
    {
        printf("Enter student's name: ");
        fgets(s[i].name, 100, stdin);
        printf("Enter student's ID: ");
        scanf("%d", &(s[i].ID));
  
        printf("Enter student's grade: ");
        scanf("\n%c", &(s[i].grade));
        fgets(temp, 8, stdin);
    }
}

/* writeRecordsToFile - write the students' information from the structures into a file
 *
 * INPUTS: s[] - the array of the structures of student
 *         n - number of the students
 *         fname - the string of file name
 * OUTPUTS: output the name, ID and grade of students into the file
 *
 * RETURN VALUE: none
 */
void writeRecordsToFile(Student s[], int n, char *fname)
{
    FILE *f;
    int i;

    if ((f = fopen(fname, "w")) == NULL)
    {
        fprintf(stderr, "Unable to open file %s\n", fname);
        exit(1);
    }
    for (i = 0; i < n; i++)
        fprintf(f, "%s%d\n%c\n", s[i].name, s[i].ID, s[i].grade);

    fclose(f);
}


/* readRecordsFromFile - read the students' information from a file into structures
 *
 * INPUTS: s[] - the array of the structures of student
 *         n - number of the students
 *         fname - the string of file name
 * OUTPUTS: output the name, ID and grade of students into the structures
 *
 * RETURN VALUE: none
 */
void readRecordsFromFile(Student s[], int n, char *fname)
{
    /* implement me! */

    FILE *f;
    int i;
    char temp[8];

    if ((f = fopen(fname, "r")) == NULL)
        exit(1);

    for (i = 0; i < n; i++)
    {
        fgets(s[i].name, 100, f);
        fscanf(f, "%d", &(s[i].ID));
        fscanf(f, "\n%c", &(s[i].grade));
        fgets(temp, 8, f);
    }

    fclose(f);
}


/* compareRecords - compare the information stored in two arrays of structures of student
 *
 * INPUTS: s1[] - one array of structures of student
 *         s2[] - the other array of structures of student
 *         n - the number of the students
 * OUTPUTS: no output
 *
 * RETURN VALUE: NOTEQUAL - the flag that two array do not have the same information
 *               EQUAL - the flag that two array have the same information
 */
int compareRecords(Student s1[], Student s2[], int n)
{
    /* implement me! */

    int i;
    char const* s1_name;
    char const* s2_name;
    
    for (i = 0; i < n; i++)
    {
        if (s1[i].ID != s2[i].ID && s1[i].grade != s2[i].grade)
            return NOTEQUAL;

        s1_name = s1[i].name;
        s2_name = s2[i].name;

        while ('\0' != *s1_name)
        {
            if (*s1_name != *s2_name)
                return NOTEQUAL;

            s1_name++; 
            s2_name++;
        }

        if ('\0' != *s2_name)
            return NOTEQUAL;

    }
    return EQUAL;
}

