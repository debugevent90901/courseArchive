int myf(int a);

int main(void)
{
    int a, b;
    a = 5;
    b = myf(a);
}

int myf(int a)
{
    int a2;
    a2 = a + a;
    return a2;
}

