#include<stdio.h>
#include<stdlib.h>
#include<string.h>
 
int main()
{
    char *p = (char*)malloc(sizeof(char)*11);
    /* Assign some value to p */
    strncpy(p, "hello\0", 6);
 
    char *name = (char*)malloc(sizeof(char)*11);
    /* Assign some value to name */
    strncpy(name, "Bye\0", 4);
 
    memcpy(p, name, sizeof(char)*11); /* Problem begins here */
 
    free(p);
    free(name);
    return 0;
}