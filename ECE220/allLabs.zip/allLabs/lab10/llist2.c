#include <stdio.h>
#include <stdlib.h>


typedef struct node_t
{
    int data;
    struct node_t *next;
} node;

void reverse(node** head);

/* Fucnction to append nodes to the Linked list. */
void append(node **head, int data)
{   
    node *temp,*n;

    temp = (node *)malloc(sizeof(node));
    temp->data=data;
    temp->next=NULL;

    n = *head;

    if(*head==NULL)
    {   
        *head=temp;
    }
    else
    {  
        while(n->next !=NULL)
    {  
        n=n->next;
    }
    
    n->next=temp;
    }
}


void printList(node *head)
{
    node *n = head;
 
    while(n != NULL)
    {
    printf("%d ",n->data);
    n = n->next;
    }
    printf("\n");
}


int main()
{
    node* head = NULL;
    node* n = NULL;

    append(&head,20);
    append(&head,10);
    append(&head,90);
    append(&head,100);
    append(&head,80);
    append(&head,0);
    append(&head,4);
    append(&head,60);
    append(&head,05);

    printf("Before:\n");
    printList(head);

    /* call your function here */
    reverse(&head);
    printf("After:\n");
    printList(head);

    /* free linked list here */
    while(head != NULL)
    {
        n = head;
        head = head->next;
        free(n);
    }

    return 0;
}

void reverse(node** head)
{
    /* add your code here */
    node *next_node,*pre_node,*n;
    n = *head;
    pre_node = *head;
    
    if (n == NULL || n->next == NULL)
    {
        return;
    }
    
    next_node = n->next;
    
    while (next_node != NULL)
    {
        n->next = next_node->next;
        next_node->next = pre_node;
        pre_node = next_node;
        next_node = n->next;
    }
    
    *head = pre_node;
}