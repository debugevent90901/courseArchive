/* compute a function */

/* use sin() function from math.h */
/* type 'man sin' in your terminal to see instructions about sin() */

#include <stdio.h>
#include <math.h>

int main()
{
    /* declarte variables */

    /* prompt user for input */

    /* get user input */

    /* for i from 0 to n(?) */
       /* compute and print x_i and f(x_i) */

    /* exit the program */
    return 0;
}

