# include <stdio.h>

/* provide swap function prototype here */
void swap(int* px, int* py);

int main()
{
    /* complete main function to demonstrate the use of swap */
	int a = 2, b = 3;
    int *pa = &a, *pb = &b;
    printf("before swap: a = %d, b = %d\n",a,b);
    swap(pa, pb);
    printf("after swap: a = %d, b = %d\n",a,b);
    return 0;

}

/*
void swap (int x, int y)
{
    int temp;
    temp = x;
    x = y;
    y = temp;
}
*/
// old function

void swap (int *px, int *py)
{
	int temp;
    temp = *px;
    *px = *py;
    *py = temp;
    return;
}